package com.devandy.web.service;

import java.util.List;

import com.devandy.web.vo.Hobby;

public interface HobbyService {
	
	List<Hobby> selectAllHobbies();
	
	
	
}
