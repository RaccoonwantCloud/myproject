package com.devandy.web.vo;

public class CommonResponse {
	boolean success;
	int code; 
	String messaage;
	
	
}
