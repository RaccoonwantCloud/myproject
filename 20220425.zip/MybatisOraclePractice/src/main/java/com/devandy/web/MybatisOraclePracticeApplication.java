package com.devandy.web;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MybatisOraclePracticeApplication {

	public static void main(String[] args) {
		SpringApplication.run(MybatisOraclePracticeApplication.class, args);
	}

}
